Flask-Sijax
####################################

Flask-Sijax is an extension for the `Flask <http://flask.pocoo.org>`_ microframework
to simplify Sijax setup and usage for Flask users.

`Sijax <http://pypi.python.org/pypi/Sijax/>`_ is a Python/jQuery library
providing easy to use AJAX capabilities to web applications.

Take a look at the documentation_ (examples included) to learn more.

.. _documentation: http://packages.python.org/Flask-Sijax

